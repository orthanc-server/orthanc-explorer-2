const SourceType = Object.freeze({
    LOCAL_ORTHANC: 0,
    REMOTE_DICOM: 1,
    REMOTE_DICOM_WEB: 2
});

export default SourceType;