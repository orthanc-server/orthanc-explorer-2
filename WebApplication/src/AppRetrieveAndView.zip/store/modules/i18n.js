let allLanguages = [
    { name: "English", key: "en" },
    { name: "Русский", key: "ru" }
]
export default allLanguages;